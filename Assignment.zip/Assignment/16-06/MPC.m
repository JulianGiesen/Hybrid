function [u_MPC, delta_MPC, z_MPC, tau_MPC, zeta_MPC, cost_MPC]= MPC(dim, const, v_ref, MLD)
    
    constraint_state = state_constraint(MLD, const, dim, v_ref);
    if dim.Np ~= dim.Nc
        contraint_input = input_constraint(dim);
    end
    
    % Define the sdpvar optimization variables
    u_MPC = sdpvar(dim.u*dim.Np,1);                               
    delta_MPC = sdpvar(dim.delta*dim.Np,1);
    z_MPC  = sdpvar(dim.z*dim.Np,1);
    tau_MPC = sdpvar(dim.tau,1);
    zeta_MPC = sdpvar(dim.zeta*dim.Np,1);

    % Creates the complete constraint matrix
    Constraint = [constraint_state.E2 * delta_MPC + constraint_state.E3 * z_MPC + constraint_state.E6 * tau_MPC <= constraint_state.E1  * u_MPC + constraint_state.E7 * zeta_MPC + constraint_state.B, ...
              eye(dim.Np*dim.u)*u_MPC <= const.u_max, ...
              -eye(dim.Np*dim.u)*u_MPC <= -const.u_min, ...
              ones(1,dim.z*dim.Np)*z_MPC <= 0];

    % Add the control horizon contraint if the statement is true    
    if dim.Np ~= dim.Nc
        Constraint = [Constraint, contraint_input.left*u_MPC <= contraint_input.right];
    end

    % Creates the objective function
    Objective = ones(1,dim.zeta*dim.Np) * zeta_MPC + const.lambda * tau_MPC;

    % Solve the optimization problem
    opt = sdpsettings('verbose',0);
    optimize(Constraint,Objective,opt);    

    % Find the final values from the sdpvar variables
    z_MPC = value(z_MPC); 
    u_MPC = value(u_MPC); 
    delta_MPC = value(delta_MPC);
    tau_MPC = value(tau_MPC);
    zeta_MPC = value(zeta_MPC);
    cost_MPC = Objective;
end
