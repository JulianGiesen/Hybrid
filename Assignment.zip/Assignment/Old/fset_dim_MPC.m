function dim = fset_dim_MPC()
dim.Np = 5;      % Prediction horizon
dim.Nc = 4;      % Control horizon
dim.x = 1;       % Number of states
dim.u = 1;       % Number of inputs
dim.delta = 3;   % Dimension of delta
dim.z = 3;       % Dimension of z
dim.tau = 1;     % Dimension of tau
dim.zeta = 1;    % Dimension of zeta
end