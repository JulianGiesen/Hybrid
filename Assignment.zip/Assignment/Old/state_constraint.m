function state_con = state_constraint(MLD, const, dim, v_ref)

    % Initialize contraint vectors
    state_con.E1 = zeros(dim.Np*length(MLD.E1),dim.u*dim.Np);
    state_con.E2 = zeros(dim.Np*length(MLD.E2),dim.delta*dim.Np);
    state_con.E3  = zeros(dim.Np*length(MLD.E3),dim.z*dim.Np);
    state_con.E4 = zeros(dim.Np*length(MLD.E4),(dim.x-1)*1);
    state_con.E5 = zeros(dim.Np*length(MLD.E5),1);
    state_con.E6 = zeros(dim.Np*length(MLD.E6),1);
    state_con.E7 = zeros(dim.Np*length(MLD.E7),dim.zeta*dim.Np);
    
    state_con.E4(1:length(MLD.E4),1) = MLD.E4*const.v0;
   
    for k = 0:dim.Np-1
        state_con.E1(k*length(MLD.E1)+1:(k+1)*length(MLD.E1), k*dim.u+1:(k+1)*dim.u) = MLD.E1;
        state_con.E2(k*length(MLD.E2)+1:(k+1)*length(MLD.E2), k*dim.delta+1:(k+1)*dim.delta) = MLD.E2;
        state_con.E3(k*length(MLD.E3)+1:(k+1)*length(MLD.E3), k*dim.z+1:(k+1)*dim.z) = MLD.E3;
        state_con.E5(k*length(MLD.E5)+1:(k+1)*length(MLD.E5), 1) = MLD.E5;
        state_con.E6(k*length(MLD.E6)+1:(k+1)*length(MLD.E6), dim.tau) = MLD.E6;
        state_con.E7(k*length(MLD.E7)+1:(k+1)*length(MLD.E7), k*dim.zeta+1:(k+1)*dim.zeta) = MLD.E7; 
    end

%     state_con.E3(11:12,1:4) = [-1; 1] * [1/const.Ts,1/const.Ts,1/const.Ts,1/const.Ts];
%     state_con.E4(11:12,1) = [-1; 1] * (1/const.Ts * const.v0);
%     state_con.E5(11:12,1) = ones(2,1) * const.a_comfmax;

    E4_z = repmat([MLD.E4],1,3);
    for k = 1:dim.Np-1 
        state_con.E3(k*length(MLD.E3)+1:(k+1)*length(MLD.E3), (k-1)*dim.z+1:(k)*dim.z) = -E4_z; 
    end

    % Tau and zeta constraint
    for k = 1:dim.Np
        state_con.E1((k-1)*length(MLD.E3)+9:(k-1)*length(MLD.E3)+10, k) = [1;-1]; 
        state_con.E5((k-1)*length(MLD.E5)+11:(k-1)*length(MLD.E5)+12,1) = [v_ref(k); -v_ref(k)];
        state_con.E5((k-1)*length(MLD.E5)+9:(k-1)*length(MLD.E5)+10, 1) = [const.a_comfmax; const.a_comfmax];
    end
    
     % 
     for k = 2:dim.Np 
         state_con.E3((k-1)*length(MLD.E3)+7:(k-1)*length(MLD.E3)+8, (k-2)*dim.z+1:(k)*dim.z) = [-1/const.Ts,-1/const.Ts,-1/const.Ts,-1/const.Ts,1/const.Ts,1/const.Ts;1/const.Ts,1/const.Ts,-1/const.Ts,-1/const.Ts,-1/const.Ts,-1/const.Ts];           
     end
    
    state_con.B = state_con.E4 + state_con.E5;
end