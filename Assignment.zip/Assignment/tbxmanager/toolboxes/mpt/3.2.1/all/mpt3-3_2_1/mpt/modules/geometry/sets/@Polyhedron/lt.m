function tf = lt(P,S)
% P less than S

tf = le(P,S);

end
