function status = gt(U1, U2)
% tests whether U1 is a strict superset of U2

error('Not yet implemented.');

end
