function S = mpt_parallel_options
%
% Option settings for "parallel" module.
%

% no options required
S = [];

end