% Thin MPT2 compatibility layer
%
% Files
%   mpt_compatibility_options - Option settings for the compatibility module.
%   mpt_obsoleteFunction      - Warn a user that function 'name' is obsolete
